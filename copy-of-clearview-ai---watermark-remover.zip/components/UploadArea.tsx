import React, { useCallback, useState } from 'react';

interface UploadAreaProps {
  onFilesSelected: (files: File[]) => void;
  disabled: boolean;
}

const UploadArea: React.FC<UploadAreaProps> = ({ onFilesSelected, disabled }) => {
  const [isDragging, setIsDragging] = useState(false);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    if (!disabled) setIsDragging(true);
  }, [disabled]);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (disabled) return;

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const filesArray = Array.from(e.dataTransfer.files);
      const imageFiles = filesArray.filter(file => file.type.startsWith('image/'));
      onFilesSelected(imageFiles);
    }
  }, [onFilesSelected, disabled]);

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const filesArray = Array.from(e.target.files);
      onFilesSelected(filesArray);
    }
  };

  return (
    <div
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className={`
        relative w-full rounded-2xl border-2 border-dashed transition-all duration-300 ease-in-out
        flex flex-col items-center justify-center py-16 px-4
        ${disabled 
          ? 'border-slate-700 bg-slate-900/30 cursor-not-allowed opacity-60' 
          : isDragging 
            ? 'border-indigo-500 bg-indigo-500/10 scale-[1.01]' 
            : 'border-slate-700 hover:border-indigo-500/50 hover:bg-slate-800/50 cursor-pointer bg-slate-900/50'
        }
      `}
    >
      <input
        type="file"
        multiple
        accept="image/*"
        onChange={handleFileInput}
        disabled={disabled}
        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer disabled:cursor-not-allowed"
      />
      
      <div className="flex flex-col items-center text-center space-y-4 pointer-events-none">
        <div className={`
          p-4 rounded-full transition-colors duration-300
          ${isDragging ? 'bg-indigo-500 text-white' : 'bg-slate-800 text-indigo-400'}
        `}>
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8">
            <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5m-13.5-9L12 3m0 0l4.5 4.5M12 3v13.5" />
          </svg>
        </div>
        <div>
          <h3 className="text-lg font-semibold text-white">
            {isDragging ? 'Drop images here' : 'Upload Images'}
          </h3>
          <p className="text-slate-400 mt-1">
            Drag & drop or click to select
          </p>
          <p className="text-xs text-slate-500 mt-2">
            Supports JPG, PNG, WEBP (Max 10 images)
          </p>
        </div>
      </div>
    </div>
  );
};

export default UploadArea;