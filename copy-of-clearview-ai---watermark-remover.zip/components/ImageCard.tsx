import React, { useState } from 'react';
import { ImageItem, ProcessingStatus } from '../types';

interface ImageCardProps {
  item: ImageItem;
  onRemove: (id: string) => void;
}

const ImageCard: React.FC<ImageCardProps> = ({ item, onRemove }) => {
  const [viewMode, setViewMode] = useState<'original' | 'processed'>('processed');

  const isProcessed = item.status === ProcessingStatus.SUCCESS && item.processedUrl;
  
  // Auto-switch to processed view when done
  React.useEffect(() => {
    if (isProcessed) {
      setViewMode('processed');
    }
  }, [isProcessed]);

  return (
    <div className="group relative bg-slate-800 rounded-xl overflow-hidden border border-slate-700 shadow-xl transition-all hover:border-slate-600 flex flex-col h-full">
      {/* Remove Button */}
      <button 
        onClick={() => onRemove(item.id)}
        className="absolute top-2 right-2 z-20 p-1.5 bg-black/50 hover:bg-red-500/80 backdrop-blur-sm rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity"
        title="Remove image"
      >
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4">
          <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
        </svg>
      </button>

      {/* Image Display Area */}
      <div className="relative aspect-[4/3] bg-slate-900 w-full overflow-hidden">
        {item.status === ProcessingStatus.IDLE && (
          <img 
            src={item.originalPreviewUrl} 
            alt="Original" 
            className="w-full h-full object-cover opacity-80"
          />
        )}

        {item.status === ProcessingStatus.PROCESSING && (
          <>
            <img 
              src={item.originalPreviewUrl} 
              alt="Processing" 
              className="w-full h-full object-cover blur-sm opacity-50"
            />
            <div className="absolute inset-0 flex flex-col items-center justify-center z-10">
              <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin mb-2"></div>
              <span className="text-xs font-medium text-indigo-400 animate-pulse">Removing Watermark...</span>
            </div>
          </>
        )}

        {item.status === ProcessingStatus.SUCCESS && (
          <div className="relative w-full h-full">
             <img 
              src={viewMode === 'processed' ? item.processedUrl : item.originalPreviewUrl} 
              alt={viewMode} 
              className="w-full h-full object-cover transition-opacity duration-300"
            />
            {/* View Toggle Badge */}
            <div className="absolute bottom-2 left-2 z-10 px-2 py-1 bg-black/60 backdrop-blur-md rounded text-[10px] font-bold text-white uppercase tracking-wider">
              {viewMode}
            </div>
          </div>
        )}

        {item.status === ProcessingStatus.ERROR && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-red-900/20 p-4 text-center">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8 text-red-500 mb-2">
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z" />
            </svg>
            <p className="text-xs text-red-200">{item.errorMessage || "Processing Failed"}</p>
          </div>
        )}
      </div>

      {/* Controls / Footer */}
      <div className="p-3 bg-slate-800 border-t border-slate-700 flex flex-col gap-2 mt-auto">
        <div className="flex items-center justify-between">
           <span className="text-xs text-slate-400 truncate max-w-[120px]" title={item.file.name}>{item.file.name}</span>
           <span className="text-[10px] text-slate-500">{(item.file.size / 1024).toFixed(0)}KB</span>
        </div>

        {item.status === ProcessingStatus.SUCCESS && (
          <div className="flex items-center gap-2 mt-1">
             <button
               onClick={() => setViewMode(viewMode === 'original' ? 'processed' : 'original')}
               className="flex-1 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-700 hover:bg-slate-600 rounded transition-colors"
             >
               {viewMode === 'original' ? 'Show Result' : 'Show Original'}
             </button>
             <a
               href={item.processedUrl}
               download={`clean_${item.file.name}`}
               className="flex-1 flex items-center justify-center gap-1 px-3 py-1.5 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-500 rounded transition-colors"
             >
               <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-3 h-3">
                 <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M12 12.75l-3-3m0 0l3-3m-3 3h7.5" />
               </svg>
               Save
             </a>
          </div>
        )}
      </div>
    </div>
  );
};

export default ImageCard;