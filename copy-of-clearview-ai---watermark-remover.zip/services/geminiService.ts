import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY || '';

// Initialize the client
const ai = new GoogleGenAI({ apiKey });

/**
 * Encodes a File object to a base64 string.
 */
export const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const result = reader.result as string;
      // Remove the Data URL prefix (e.g., "data:image/jpeg;base64,")
      const base64Data = result.split(',')[1];
      resolve(base64Data);
    };
    reader.onerror = (error) => reject(error);
  });
};

/**
 * Sends the image to Gemini to remove watermarks.
 */
export const removeWatermarkFromImage = async (
  base64Data: string,
  mimeType: string
): Promise<string> => {
  if (!apiKey) {
    throw new Error("API Key is missing. Please check your configuration.");
  }

  try {
    // We use gemini-2.5-flash-image for image editing/inpainting tasks
    const model = 'gemini-2.5-flash-image';

    const response = await ai.models.generateContent({
      model: model,
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: mimeType,
              data: base64Data,
            },
          },
          {
            text: "Edit this image. Remove all watermarks, logos, text overlays, and stamps. Reconstruct the background behind the removed elements seamlessly to match the surrounding area. The output must be the cleaned image only.",
          },
        ],
      },
    });

    // Extract the image from the response
    const parts = response.candidates?.[0]?.content?.parts;
    
    if (!parts || parts.length === 0) {
      throw new Error("No content returned from the model.");
    }

    // Look for the inlineData part which contains the generated image
    const imagePart = parts.find(p => p.inlineData);

    if (imagePart && imagePart.inlineData && imagePart.inlineData.data) {
      return imagePart.inlineData.data;
    } 
    
    // If only text is returned, it might be a refusal or error explanation
    const textPart = parts.find(p => p.text);
    if (textPart && textPart.text) {
      throw new Error(`Model returned text instead of image: ${textPart.text}`);
    }

    throw new Error("Failed to generate image. Unexpected response format.");

  } catch (error: any) {
    console.error("Gemini API Error:", error);
    throw new Error(error.message || "An error occurred during watermark removal.");
  }
};